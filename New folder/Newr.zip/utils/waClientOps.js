const { MessageMedia } = require('whatsapp-web.js');
const { withTimeout } = require('./withTimeout');

const RESOLVE_JID_TIMEOUT_MS = 8_000;
const CHECK_REGISTERED_TIMEOUT_MS = 8_000;
const DEFAULT_SEND_TIMEOUT_MS = 45_000;

function cleanDigits(phone) {
  let cleaned = String(phone || '').trim();
  if (cleaned.includes('@')) {
    cleaned = cleaned.split('@')[0];
  }
  cleaned = cleaned.replace(/[^\d]/g, '');
  if (!cleaned) {
    throw new Error('Invalid phone number format');
  }
  return cleaned;
}

function toCusJid(phone) {
  return `${cleanDigits(phone)}@c.us`;
}

async function findChatJidViaStore(client, phone) {
  const page = client.pupPage;
  if (!page) {
    return null;
  }
  const digits = cleanDigits(phone);
  return page.evaluate(async (phoneDigits) => {
    try {
      if (!window.Store?.Chat) {
        return null;
      }
      const chats = window.Store.Chat.getModelsArray?.() || [];
      for (const chat of chats) {
        const serialized = chat?.id?._serialized || '';
        const user = chat?.id?.user || '';
        if (user === phoneDigits || serialized.startsWith(`${phoneDigits}@`)) {
          return serialized;
        }
      }
      return null;
    } catch {
      return null;
    }
  }, digits);
}

async function queryExistViaStore(client, jid) {
  const page = client.pupPage;
  if (!page) {
    return null;
  }
  return page.evaluate(async (id) => {
    try {
      if (!window.Store?.QueryExist || !window.Store?.Wid) {
        return null;
      }
      const wid = window.Store.Wid.createWid(id);
      const result = await window.Store.QueryExist(wid);
      if (result?.wid) {
        return result.wid._serialized || id;
      }
      return null;
    } catch {
      return null;
    }
  }, jid);
}

async function resolveRecipientJid(client, phone, options = {}) {
  const timeoutMs = options.timeoutMs ?? RESOLVE_JID_TIMEOUT_MS;
  const defaultJid = toCusJid(phone);
  const log = options.logPrefix
    ? (msg) => console.log(`${options.logPrefix} ${msg}`)
    : () => {};

  log(`resolve jid start ${defaultJid}`);

  try {
    const fromChat = await withTimeout(
      findChatJidViaStore(client, phone),
      timeoutMs,
      'WhatsApp find chat',
    );
    if (fromChat) {
      log(`resolve jid via chat → ${fromChat}`);
      return fromChat;
    }
  } catch (err) {
    log(`resolve chat lookup failed: ${err.message}`);
  }

  try {
    const fromQuery = await withTimeout(
      queryExistViaStore(client, defaultJid),
      timeoutMs,
      'WhatsApp QueryExist',
    );
    if (fromQuery) {
      log(`resolve jid via QueryExist → ${fromQuery}`);
      return fromQuery;
    }
  } catch (err) {
    log(`resolve QueryExist failed: ${err.message}`);
  }

  log(`resolve jid fallback → ${defaultJid}`);
  return defaultJid;
}

/**
 * Check if a phone is on WhatsApp — store lookups only (no isRegisteredUser/getNumberId).
 */
async function checkRegistered(client, phone, options = {}) {
  const timeoutMs = options.timeoutMs ?? CHECK_REGISTERED_TIMEOUT_MS;
  const jid = toCusJid(phone);
  const t0 = Date.now();
  const log = options.logPrefix
    ? (msg) => console.log(`${options.logPrefix} ${msg}`)
    : () => {};

  log(`check start jid=${jid}`);

  try {
    const fromChat = await withTimeout(
      findChatJidViaStore(client, phone),
      timeoutMs,
      'WhatsApp find chat',
    );
    if (fromChat) {
      log(`check done (${Date.now() - t0}ms) exists=true via=chat`);
      return { exists: true, jid: fromChat };
    }
  } catch (err) {
    log(`check chat lookup failed: ${err.message}`);
  }

  try {
    const resolvedJid = await withTimeout(
      queryExistViaStore(client, jid),
      timeoutMs,
      'WhatsApp QueryExist',
    );
    const exists = !!resolvedJid;
    log(`check done (${Date.now() - t0}ms) exists=${exists} via=QueryExist`);
    return { exists, jid: resolvedJid || jid };
  } catch (err) {
    log(`check QueryExist failed: ${err.message}`);
    return { exists: false, jid };
  }
}

async function sendViaStore(client, jid, text) {
  const page = client.pupPage;
  if (!page) {
    throw new Error('Browser page not available');
  }
  return page.evaluate(
    async (id, body) => {
      if (!window.Store?.Wid || !window.Store?.Chat || !window.Store?.SendMessage) {
        throw new Error('WhatsApp Store not ready');
      }
      const wid = window.Store.Wid.createWid(id);
      let chat = window.Store.Chat.get(wid);
      if (!chat) {
        chat = await window.Store.Chat.find(wid);
      }
      if (!chat) {
        const digits = id.split('@')[0];
        chat = (window.Store.Chat.getModelsArray?.() || []).find(
          (c) => c?.id?.user === digits,
        );
      }
      if (!chat) {
        throw new Error('Chat not found');
      }
      const msg = await window.Store.SendMessage.sendMessage(chat, body);
      return msg?.id?._serialized || null;
    },
    jid,
    text,
  );
}

/** Same Puppeteer path as send-media — avoids blocking client.sendMessage(string). */
async function sendTextAsMediaFile(client, jid, text) {
  const b64 = Buffer.from(String(text), 'utf8').toString('base64');
  const media = new MessageMedia('text/plain', b64, 'message.txt');
  return client.sendMessage(jid, media);
}

async function sendTextSafe(client, phone, text, options = {}) {
  const timeoutMs = options.timeoutMs ?? DEFAULT_SEND_TIMEOUT_MS;
  const logPrefix = options.logPrefix || '';
  const log = logPrefix ? (msg) => console.log(`${logPrefix} ${msg}`) : () => {};
  const t0 = Date.now();

  const jid = await resolveRecipientJid(client, phone, {
    timeoutMs: RESOLVE_JID_TIMEOUT_MS,
    logPrefix,
  });
  log(`send jid=${jid}`);

  try {
    const msgId = await withTimeout(
      sendViaStore(client, jid, text),
      timeoutMs,
      'WhatsApp store send',
    );
    log(`send done (${Date.now() - t0}ms) via=store id=${msgId}`);
    return { id: { _serialized: msgId } };
  } catch (err) {
    log(`store send failed: ${err.message}`);
  }

  try {
    const sent = await withTimeout(
      sendTextAsMediaFile(client, jid, text),
      timeoutMs,
      'WhatsApp media-path send',
    );
    log(`send done (${Date.now() - t0}ms) via=media-file`);
    return sent;
  } catch (err) {
    log(`media-path send failed: ${err.message}`);
    throw err;
  }
}

module.exports = {
  cleanDigits,
  toCusJid,
  checkRegistered,
  resolveRecipientJid,
  sendTextSafe,
  RESOLVE_JID_TIMEOUT_MS,
  CHECK_REGISTERED_TIMEOUT_MS,
  DEFAULT_SEND_TIMEOUT_MS,
};
