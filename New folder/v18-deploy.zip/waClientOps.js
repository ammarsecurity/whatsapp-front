const { MessageMedia } = require('whatsapp-web.js');
const { withTimeout } = require('./withTimeout');

const CHECK_CHAT_TIMEOUT_MS = 5_000;
const DEFAULT_SEND_TIMEOUT_MS = 45_000;

function cleanDigits(phone) {
  let cleaned = String(phone || '').trim();
  if (cleaned.includes('@')) {
    cleaned = cleaned.split('@')[0];
  }
  cleaned = cleaned.replace(/[^\d]/g, '');
  if (!cleaned) {
    throw new Error('Invalid phone number format');
  }
  return cleaned;
}

function toCusJid(phone) {
  return `${cleanDigits(phone)}@c.us`;
}

async function findChatJidViaStore(client, phone) {
  const page = client.pupPage;
  if (!page) {
    return null;
  }
  const digits = cleanDigits(phone);
  return page.evaluate(async (phoneDigits) => {
    try {
      if (!window.Store?.Chat) {
        return null;
      }
      const chats = window.Store.Chat.getModelsArray?.() || [];
      for (const chat of chats) {
        const serialized = chat?.id?._serialized || '';
        const user = chat?.id?.user || '';
        if (user === phoneDigits || serialized.startsWith(`${phoneDigits}@`)) {
          return serialized;
        }
      }
      return null;
    } catch {
      return null;
    }
  }, digits);
}

/**
 * Fast check — findChat only (no QueryExist / isRegisteredUser / getNumberId).
 */
async function checkRegistered(client, phone, options = {}) {
  const timeoutMs = options.timeoutMs ?? CHECK_CHAT_TIMEOUT_MS;
  const jid = toCusJid(phone);
  const t0 = Date.now();
  const log = options.logPrefix
    ? (msg) => console.log(`${options.logPrefix} ${msg}`)
    : () => {};

  log(`check start jid=${jid}`);

  try {
    const fromChat = await withTimeout(
      findChatJidViaStore(client, phone),
      timeoutMs,
      'WhatsApp find chat',
    );
    if (fromChat) {
      log(`check done (${Date.now() - t0}ms) exists=true via=chat`);
      return { exists: true, jid: fromChat };
    }
  } catch (err) {
    log(`check chat lookup failed: ${err.message}`);
  }

  log(`check done (${Date.now() - t0}ms) exists=false`);
  return { exists: false, jid };
}

async function sendViaStore(client, jid, text) {
  const page = client.pupPage;
  if (!page) {
    throw new Error('Browser page not available');
  }
  return page.evaluate(
    async (id, body) => {
      if (!window.Store?.Wid || !window.Store?.Chat || !window.Store?.SendMessage) {
        throw new Error('WhatsApp Store not ready');
      }
      const wid = window.Store.Wid.createWid(id);
      let chat = window.Store.Chat.get(wid);
      if (!chat) {
        chat = await window.Store.Chat.find(wid);
      }
      if (!chat) {
        const digits = id.split('@')[0];
        chat = (window.Store.Chat.getModelsArray?.() || []).find(
          (c) => c?.id?.user === digits,
        );
      }
      if (!chat) {
        throw new Error('Chat not found');
      }
      const msg = await window.Store.SendMessage.sendMessage(chat, body);
      return msg?.id?._serialized || null;
    },
    jid,
    text,
  );
}

/** Same Puppeteer path as send-media — proven to work when text send hangs. */
async function sendTextAsMediaFile(client, jid, text) {
  const b64 = Buffer.from(String(text), 'utf8').toString('base64');
  const media = new MessageMedia('text/plain', b64, 'message.txt');
  return client.sendMessage(jid, media);
}

async function sendTextSafe(client, phone, text, options = {}) {
  const timeoutMs = options.timeoutMs ?? DEFAULT_SEND_TIMEOUT_MS;
  const logPrefix = options.logPrefix || '';
  const log = logPrefix ? (msg) => console.log(`${logPrefix} ${msg}`) : () => {};
  const t0 = Date.now();
  const jid = toCusJid(phone);

  log(`send start jid=${jid} (media-path first)`);

  try {
    const sent = await withTimeout(
      sendTextAsMediaFile(client, jid, text),
      timeoutMs,
      'WhatsApp media-path send',
    );
    log(`send done (${Date.now() - t0}ms) via=media-file`);
    return sent;
  } catch (err) {
    log(`media-path send failed: ${err.message}`);
  }

  try {
    const msgId = await withTimeout(
      sendViaStore(client, jid, text),
      timeoutMs,
      'WhatsApp store send',
    );
    log(`send done (${Date.now() - t0}ms) via=store id=${msgId}`);
    return { id: { _serialized: msgId } };
  } catch (err) {
    log(`store send failed: ${err.message}`);
    throw err;
  }
}

module.exports = {
  cleanDigits,
  toCusJid,
  checkRegistered,
  sendTextSafe,
  CHECK_CHAT_TIMEOUT_MS,
  DEFAULT_SEND_TIMEOUT_MS,
};
